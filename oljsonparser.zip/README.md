# ol-json-parser (Blob trigger)

Triggered when a new raw OpenLineage JSON lands in `openlineage-events`. It:
1) Parses inputs/outputs from the event
2) Creates/refs dataset entities (matching your ADLS scanned assets)
3) Creates a Process entity (`azure_synapse_operation`) with `columnMapping`
4) Uploads all to Purview in one batch

## Deploy

```bash
# from this folder
func azure functionapp publish <your-parser-app-name>
```

## Important
- Ensure your dataset `qualifiedName` **matches** Purview scanner output (abfss://container@account.dfs.core.windows.net/path).
- If your events use different fields for dataset URIs, adapt `normalize_qn()` accordingly.