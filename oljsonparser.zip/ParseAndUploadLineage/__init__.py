import azure.functions as func
import logging
import os
import json

from azure.identity import ChainedTokenCredential, ManagedIdentityCredential, AzureCliCredential
from pyapacheatlas.core import PurviewClient, AtlasEntity, AtlasProcess
from pyapacheatlas.core.util import GuidTracker
from pyapacheatlas.core.typedef import AtlasAttributeDef, EntityTypeDef

app = func.FunctionApp()

# Environment Configuration
PURVIEW_NAME = os.environ.get("PURVIEW_NAME")

# Dataset & Process type configuration
INPUT_TYPE = os.environ.get("INPUT_ENTITY_TYPE", "azure_datalake_gen2_resource_set")
OUTPUT_TYPE = os.environ.get("OUTPUT_ENTITY_TYPE", "azure_datalake_gen2_resource_set")
PROCESS_TYPE = os.environ.get("PROCESS_ENTITY_TYPE", "azure_synapse_operation")
ENABLE_COL_MAP = os.environ.get("ENABLE_COLUMN_MAPPING", "true").lower() == "true"
DEFAULT_MAP_IDENTITY = os.environ.get("DEFAULT_COL_MAP_IDENTITY", "true").lower() == "true"


def normalize_qn(path):
    """
    Normalize qualified names for Purview.
    Pass-through function that can be extended for custom transformations.
    """
    return path


def _ensure_types(client):
    """
    Ensure required entity types exist in Purview.
    Skips Microsoft built-in types to avoid modification errors.
    """
    # Microsoft built-in types that cannot be modified
    BUILTIN_TYPES = {
        "azure_synapse_operation",
        "azure_synapse_serverless_sql_table",
        "azure_datalake_gen2_resource_set",
        "azure_datalake_gen2_path",
        "azure_synapse_workspace",
        "azure_synapse_notebook",
        "azure_synapse_pipeline",
        "azure_synapse_spark_job",
        "azure_synapse_dataflow"
    }

    # Check if the process type is built-in
    if PROCESS_TYPE in BUILTIN_TYPES:
        logging.info(f"Using Microsoft built-in type: {PROCESS_TYPE} - skipping type creation")
        return

    # Only create custom types
    logging.info(f"Creating custom type: {PROCESS_TYPE}")
    typedef = EntityTypeDef(
        name=PROCESS_TYPE,
        superTypes=["Process"],
        attributes=[AtlasAttributeDef(name="columnMapping")]
    )
    try:
        client.upload_typedefs(entityDefs=[typedef], force_update=False)
        logging.info(f"Successfully created custom type: {PROCESS_TYPE}")
    except Exception as e:
        logging.warning(f"Type creation failed (may already exist): {e}")


def _build_column_mapping(inputs, outputs, cols_in, cols_out):
    """
    Build column-level lineage mapping between input and output datasets.
    Returns JSON string representing the column mapping.
    """
    if not inputs or not outputs:
        return "[]"

    src = inputs[0]
    sink = outputs[0]
    mapping = []

    if not cols_in or not cols_out:
        if DEFAULT_MAP_IDENTITY:
            pairs = [{"Source": c, "Sink": c} for c in set(cols_in or []) & set(cols_out or [])]
        else:
            pairs = []
    else:
        intersect = set(cols_in) & set(cols_out)
        pairs = [{"Source": c, "Sink": c} for c in sorted(intersect)]

    mapping.append({
        "DatasetMapping": {"Source": src, "Sink": sink},
        "ColumnMapping": pairs
    })

    return json.dumps(mapping, separators=(",", ":"))


def _extract_columns_from_facets(evt):
    """
    Extract column names from OpenLineage event facets.
    Returns tuple of (input_columns, output_columns) as sorted lists.
    """
    cols_in = []
    cols_out = []

    try:
        for ds in evt.get("inputs", []) or []:
            fields = (ds.get("facets", {}) or {}).get("schema", {}) or {}
            names = [f.get("name") for f in (fields.get("fields") or [])
                    if isinstance(f, dict) and f.get("name")]
            cols_in.extend(names)

        for ds in evt.get("outputs", []) or []:
            fields = (ds.get("facets", {}) or {}).get("schema", {}) or {}
            names = [f.get("name") for f in (fields.get("fields") or [])
                    if isinstance(f, dict) and f.get("name")]
            cols_out.extend(names)
    except Exception as e:
        logging.warning(f"Failed to extract columns from facets: {e}")

    cols_in = sorted(list(set([c for c in cols_in if c])))
    cols_out = sorted(list(set([c for c in cols_out if c])))

    return cols_in, cols_out


@app.function_name(name="ParseAndUploadLineage")
@app.blob_trigger(
    arg_name="blob",
    path="openlineage-events",
    connection="AzureWebJobsStorage"
)
def main(blob: func.InputStream):
    """
    Main function to process OpenLineage events and create lineage in Purview.
    """
    logging.info(f"ParseAndUploadLineage triggered. Blob: {blob.name}, Size: {blob.length} bytes")

    # Parse the OpenLineage event
    try:
        evt = json.loads(blob.read().decode("utf-8"))
        job_name = evt.get('job', {}).get('name', 'unknown')
        event_type = evt.get('eventType', 'unknown')
        logging.info(f"Processing OpenLineage event: {event_type} for job: {job_name}")
    except Exception as e:
        logging.error(f"Failed to parse blob content: {e}")
        return

    # Authenticate to Purview
    credential = ChainedTokenCredential(
        ManagedIdentityCredential(),
        AzureCliCredential()
    )

    try:
        client = PurviewClient(account_name=PURVIEW_NAME, authentication=credential)
        logging.info(f"Connected to Purview: {PURVIEW_NAME}")
    except Exception as e:
        logging.error(f"Failed to connect to Purview: {e}")
        return

    # Ensure types exist
    _ensure_types(client)

    # Extract dataset qualified names
    def ds_qn_list(kind):
        ds = evt.get(kind, []) or []
        qns = []
        for d in ds:
            qn = d.get("name") or d.get("uri") or d.get("namespace")
            if not qn and d.get("facets", {}).get("dataSource", {}).get("name"):
                qn = d["facets"]["dataSource"]["name"]
            if qn:
                qns.append(normalize_qn(qn))
        return qns

    input_qns = ds_qn_list("inputs")
    output_qns = ds_qn_list("outputs")

    logging.info(f"Input datasets ({len(input_qns)}): {input_qns}")
    logging.info(f"Output datasets ({len(output_qns)}): {output_qns}")

    # Build Purview entities
    gt = GuidTracker()
    entities = []
    input_entities = []
    output_entities = []

    for qn in input_qns:
        input_entities.append(AtlasEntity(
            typeName=INPUT_TYPE,
            qualified_name=qn,
            name=os.path.basename(qn),
            guid=gt.get_guid()
        ))

    for qn in output_qns:
        output_entities.append(AtlasEntity(
            typeName=OUTPUT_TYPE,
            qualified_name=qn,
            name=os.path.basename(qn),
            guid=gt.get_guid()
        ))

    entities.extend(input_entities)
    entities.extend(output_entities)

    # Extract job and run information
    job = evt.get("job", {}) or {}
    run = evt.get("run", {}) or {}

    namespace = job.get("namespace") or "synapse"
    job_name = job.get("name") or "notebook"
    run_id = run.get("runId") or "run"

    process_qn = f"synapse://{namespace}/{job_name}/{run_id}"
    attributes = {}

    # Build column-level lineage if enabled
    if ENABLE_COL_MAP:
        cols_in, cols_out = _extract_columns_from_facets(evt)
        if cols_in or cols_out:
            attributes["columnMapping"] = _build_column_mapping(input_qns, output_qns, cols_in, cols_out)
            logging.info(f"Column mapping: {len(cols_in)} input columns → {len(cols_out)} output columns")

    # Create process entity
    proc = AtlasProcess(
        typeName=PROCESS_TYPE,
        qualified_name=process_qn,
        name=job_name,
        guid=gt.get_guid(),
        inputs=input_entities,
        outputs=output_entities,
        attributes=attributes
    )

    entities.append(proc)

    logging.info(f"Uploading {len(entities)} entities to Purview (process: {process_qn})")

    # Upload to Purview
    try:
        res = client.upload_entities(batch=entities)
        logging.info(f"Successfully uploaded entities to Purview: {res}")
        logging.info(f"Lineage created for job: {job_name}")
    except Exception as e:
        logging.error(f"Failed to upload entities to Purview: {e}")
        raise