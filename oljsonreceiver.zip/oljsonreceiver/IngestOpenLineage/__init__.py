
import logging, os, json, uuid, datetime
import azure.functions as func
from azure.storage.blob import BlobClient
from azure.data.tables import TableClient, UpdateMode

app = func.FunctionApp()

STORAGE_CONNECTION      = os.environ["STORAGE_CONNECTION"]
EVENTS_CONTAINER        = os.environ.get("EVENTS_CONTAINER", "openlineage-events")
DEADLETTER_CONTAINER    = os.environ.get("DEADLETTER_CONTAINER", "openlineage-deadletter")
TABLE_NAME              = os.environ.get("TABLE_NAME", "LineageJobs")
ALLOWED_EVENT_TYPES     = set(s.strip().upper() for s in os.environ.get("ALLOWED_EVENT_TYPES", "COMPLETE").split(",") if s.strip())
ALLOW_SQL_ONLY          = os.environ.get("ALLOW_SQL_ONLY", "true").lower() == "true"
MAX_CONTENT_LENGTH      = int(os.environ.get("MAX_CONTENT_LENGTH", str(8 * 1024 * 1024)))
WRITE_TABLE             = os.environ.get("WRITE_TABLE", "true").lower() == "true"

def _now():
    return datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc)

def _ymd(dt: datetime.datetime):
    return dt.strftime("%Y"), dt.strftime("%m"), dt.strftime("%d")

def _is_sql_like(evt: dict) -> bool:
    job = (evt.get("job") or {})
    facets = (job.get("facets") or {})
    if any(k in facets for k in ("sql","spark_sql","sourceCode")):
        return True
    run_facets = ((evt.get("run") or {}).get("facets") or {})
    if "sql" in run_facets:
        return True
    return bool(evt.get("inputs") or evt.get("outputs"))

def _blob_upload(container: str, name: str, data: bytes):
    bc = BlobClient.from_connection_string(STORAGE_CONNECTION, container_name=container, blob_name=name)
    bc.upload_blob(data, overwrite=True)

def _table_upsert(partition_key: str, row_key: str, entity: dict):
    if not WRITE_TABLE:
        return
    tc = TableClient.from_connection_string(STORAGE_CONNECTION, table_name=TABLE_NAME)
    try:
        tc.create_table()
    except Exception:
        pass
    entity["PartitionKey"] = partition_key
    entity["RowKey"] = row_key
    tc.upsert_entity(entity=entity, mode=UpdateMode.MERGE)

def _handle_event(evt: dict) -> (bool, str):
    etype = (evt.get("eventType") or "").upper()
    if ALLOWED_EVENT_TYPES and etype not in ALLOWED_EVENT_TYPES:
        return False, f"Skipped eventType={etype}"
    if ALLOW_SQL_ONLY and not _is_sql_like(evt):
        return False, "Skipped non-SQL-like event"

    event_time = evt.get("eventTime")
    try:
        dt = datetime.datetime.fromisoformat(event_time.replace("Z", "+00:00")) if event_time else _now()
    except Exception:
        dt = _now()
    y, m, d = _ymd(dt)

    event_id = (evt.get("run") or {}).get("runId") or str(uuid.uuid4())
    blob_name = f"y={y}/m={m}/d={d}/{event_id}.json"

    payload = json.dumps(evt, separators=(",",":")).encode("utf-8")
    _blob_upload(EVENTS_CONTAINER, blob_name, payload)

    job = (evt.get("job") or {})
    job_name = job.get("name") or "unknown"
    namespace = job.get("namespace") or (evt.get("producer") or "unknown")
    _table_upsert(
        partition_key=f"{y}{m}{d}",
        row_key=event_id,
        entity={
            "blobPath": blob_name,
            "jobName": job_name,
            "namespace": namespace,
            "eventType": etype
        }
    )
    return True, f"Stored {blob_name}"

@app.route(route="IngestOpenLineage", auth_level=func.AuthLevel.FUNCTION)
def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        raw = req.get_body()
    except Exception:
        return func.HttpResponse("Bad Request: no body", status_code=400)

    if raw and len(raw) > MAX_CONTENT_LENGTH:
        return func.HttpResponse(f"Request too large (> {MAX_CONTENT_LENGTH} bytes).", status_code=413)

    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception as e:
        logging.warning("Invalid JSON: %s", e)
        return func.HttpResponse("Bad Request: invalid JSON", status_code=400)

    events = data if isinstance(data, list) else [data]

    accepted = 0
    stored = 0
    skipped = 0
    failed = 0
    errors = []

    for evt in events:
        try:
            ok, msg = _handle_event(evt)
            if ok:
                accepted += 1
                stored += 1
            else:
                skipped += 1
            logging.info(msg)
        except Exception as e:
            failed += 1
            logging.exception("Failed to handle event")
            try:
                y, m, d = _ymd(_now())
                dead_name = f"y={y}/m={m}/d={d}/dead_{uuid.uuid4()}.json"
                _blob_upload(DEADLETTER_CONTAINER, dead_name, json.dumps(evt, separators=(",",":")).encode("utf-8"))
            except Exception:
                logging.exception("Deadletter write failed")
            errors.append(str(e))

    resp = {
        "accepted": accepted,
        "stored": stored,
        "skipped": skipped,
        "failed": failed
    }
    if failed:
        resp["errors"] = errors[:5]
    return func.HttpResponse(json.dumps(resp), status_code=202, mimetype="application/json")
